package com.ElAdagioDeJP.LandingTuner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LandingTunerApplicationTests {

	@Test
	void contextLoads() {
	}

}
